require('dotenv').config();
console.log("Current Directory:", process.cwd());
console.log("MONGODB_URI:", process.env.MONGODB_URI);
